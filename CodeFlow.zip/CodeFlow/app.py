from flask import Flask, render_template, request, jsonify
import mysql.connector

app = Flask(__name__)

# Configuración de la conexión a la base de datos
db_config = {
    'user': 'CodeFlow',
    'password': 'CodeFlow202121560202121548',
    'host': 'localhost',
    'database': 'codeflow',
    'raise_on_warnings': True
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/procesar_registro', methods=['POST'])
def procesar_registro():
    try:
        # Obtener datos del formulario
        data = request.get_json()
        full_name = data.get('full_name')
        phone_number = data.get('phone_number')
        email = data.get('email')
        password = data.get('password')

        # Conectar a la base de datos y realizar la inserción
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Ejecutar la consulta de inserción
        query = "INSERT INTO Usuarios (full_name, phone_number, email, password) VALUES (%s, %s, %s, %s)"
        values = (full_name, phone_number, email, password)
        cursor.execute(query, values)

        # Confirmar la transacción
        conn.commit()

        return 'Registro exitoso'
    except mysql.connector.Error as err:
        return jsonify({'error': f'Error al procesar el registro: {err}'}), 500
    finally:
        # Cerrar la conexión al finalizar las operaciones
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

if __name__ == '__main__':
    app.run(debug=True)
