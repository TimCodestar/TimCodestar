import mysql.connector

# Configuración de la conexión
config = {
    'user': 'CodeFlow',
    'password': 'CodeFlow202121560202121548',
    'host': 'localhost',
    'database': 'codeflow',
    'raise_on_warnings': True
}

# Crear la conexión
try:
    conn = mysql.connector.connect(**config)
    print("Conexión establecida a la base de datos.")
except mysql.connector.Error as err:
    print(f"Error al conectar a la base de datos: {err}")
finally:
    if 'conn' in locals() and conn.is_connected():
        conn.close()
        print("Conexión cerrada.")
