function register() {
    var fullName = document.getElementById('full_name').value;
    var email = document.getElementById('email_reg').value;
    var password = document.getElementById('password_reg').value;

    // Objeto con los datos del formulario
    var formData = {
        full_name: fullName,
        email: email,
        password: password
    };

    // Enviar los datos al servidor utilizando AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/procesar_registro', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alert(xhr.responseText); // Puedes manejar la respuesta del servidor como desees
            } else {
                alert('Error en la solicitud al servidor.');
            }
        }
    };
    xhr.send(JSON.stringify(formData));
}
